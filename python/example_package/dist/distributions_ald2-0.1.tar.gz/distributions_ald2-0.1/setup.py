from setuptools import setup

setup(name='distributions_ald2',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_ald2'],
      zip_safe=False)
